// script.js

// 1) 폼 요소를 가장 먼저 참조
const form           = document.getElementById('restaurant-form');
const nameInput      = document.getElementById('name-input');
const addressInput   = document.getElementById('address-input');
const categoryInput  = document.getElementById('category-input');
const searchForm     = document.getElementById('search-form');
const searchInput    = document.getElementById('search-input');
const searchMessage  = document.getElementById('search-message');

// 1-a) 이미지에서 뽑은 15개 카테고리 이름 배열
const categories = [
  "패스트푸드",
  "카페·디저트",
  "치킨",
  "분식",
  "피자",
  "한식",
  "양식",
  "돈까스·회",
  "중식",
  "찜·탕",
  "야식",
  "고기",
  "족발·보쌈",
  "도시락",
  "아시안"
];

// 1-b) <select> 내부 옵션 동적 생성
categoryInput.innerHTML = '';
categories.forEach(cat => {
  const opt = document.createElement('option');
  opt.value       = cat;
  opt.textContent = cat;
  categoryInput.appendChild(opt);
});

// 2) 지도 초기화
const mapContainer = document.getElementById('map');
const mapOption    = {
  center: new kakao.maps.LatLng(37.5665, 126.9780), // 서울 시청 기준
  level: 3
};
const map = new kakao.maps.Map(mapContainer, mapOption);

// 3) 데이터·마커 관리 변수
let dataSet       = [];  // 초기 빈 배열 → GET 응답으로 덮어씌움
let markers       = [];
const infoWindow  = new kakao.maps.InfoWindow({ zIndex: 1 });
const geocoder    = new kakao.maps.services.Geocoder();

// 마커 추가 함수
function addMarker(place) {
  const marker = new kakao.maps.Marker({
    map,
    position: new kakao.maps.LatLng(place.lat, place.lng)
  });
  kakao.maps.event.addListener(marker, 'click', () => {
    infoWindow.setContent(
      `<div style="padding:5px;">
         ${place.name}<br/>
         (${place.category})
       </div>`
    );
    infoWindow.open(map, marker);
  });
  markers.push(marker);
}

// 기존 마커 전부 지우기
function clearMarkers() {
  markers.forEach(m => m.setMap(null));
  markers = [];
}

// 배열로부터 마커 모두 그리기
function displayMarkers(data) {
  clearMarkers();
  data.forEach(addMarker);
}

// 4) 초기 데이터 로드 (GET)
fetch('/api/restaurants/')
  .then(res => res.json())
  .then(data => {
    dataSet = data;
    displayMarkers(dataSet);
    console.log('초기 맛집 로드:', dataSet);
  })
  .catch(err => console.error('초기 GET 에러:', err));

// 5) 폼 제출 → 주소 변환 → API POST → 마커 추가
form.addEventListener('submit', e => {
  e.preventDefault();

  const name     = nameInput.value.trim();
  const address  = addressInput.value.trim();
  const category = categoryInput.value;

  if (!name || !address) {
    return alert('가게 이름과 주소를 모두 입력해주세요.');
  }

  // 5-1) 주소 → 좌표 변환
  geocoder.addressSearch(address, (result, status) => {
    if (status !== kakao.maps.services.Status.OK) {
      return alert('주소를 찾을 수 없습니다.');
    }

    const lat = result[0].y;
    const lng = result[0].x;
    const payload = { name, address, category, lat, lng };

    // 5-2) API에 저장
    fetch('/api/restaurants/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    .then(res => {
      if (!res.ok) throw new Error('서버 저장 실패: ' + res.status);
      return res.json();
    })
    .then(newPlace => {
      dataSet.push(newPlace);
      addMarker(newPlace);
      form.reset();
      alert('🎉 새 맛집 등록이 완료되었습니다!');
      console.log('새 맛집 저장:', newPlace);
    })
    .catch(err => {
      console.error('POST 에러:', err);
      alert('데이터 저장 중 오류가 발생했습니다.');
    });
  });
});

// 6) 검색 로직 구현
searchForm.addEventListener('submit', e => {
  e.preventDefault();
  const q = searchInput.value.trim();

  console.log('🕹️ 검색어:', q);
  console.log('🔥 dataSet names:', dataSet.map(p => p.name));

  if (!q) {
    searchMessage.textContent = '검색어를 입력해주세요.';
    return;
  }

  // name에 쿼리가 포함된 맛집 필터링
  const result = dataSet.filter(p => p.name.includes(q));
  if (result.length === 0) {
    searchMessage.textContent = `'${q}' 검색 결과가 없습니다.`;
  } else {
    searchMessage.textContent = '';
    const place = result[0];
    const latlng = new kakao.maps.LatLng(place.lat, place.lng);
    map.panTo(latlng);

    // 해당 마커 찾기
    const marker = markers.find(m => {
      const pos = m.getPosition();
      return pos.getLat() === place.lat && pos.getLng() === place.lng;
    });

    if (marker) {
      infoWindow.setContent(
        `<div style="padding:5px;">
           ${place.name}<br/>
           (${place.category})
         </div>`
      );
      infoWindow.open(map, marker);
    }
  }

  // 검색어 초기화
  searchInput.value = '';
});
