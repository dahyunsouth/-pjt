# restaurants/urls.py

from django.urls import path
from .views import restaurant_list_create

urlpatterns = [
    path('restaurants/', restaurant_list_create, name='restaurant-list-create'),
]
